/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paises;

/**
 *
 * @author RUBEN
 */
public class Mexico extends pais{

public String getpais(){
  return "Mexico";
  
}
public String getpresidente(){
   return "Lopez Obrador";
}
    
}
