

public class Alumno;{
    
String nombre;
String apellido;
String edad;
String sexo; 
String Nacionalidad;
String estatura;
String peso; 

public static void main (String [] args ){
Alumno alumno= new Alumno=();
alumno.nombre="Paola";
alumno.apellido = "Reyes";
alumno.edad= "19";
alumno.sexo= "femenino";
alumno.Nacionalidad = "Hondureña";
alumno.estatura= "1.59";
alumno.peso= "120 lbs";

System.out.println("Mi nombre es:" + alumno.nombre);
System.out.println("Mi apellido es:" + alumno.apellido);
System.out.println("Mi edad es:" + alumno.edad);
System.out.println("Mi sexo es:" + alumno.sexo);
System.out.println("Mi Nacionalidad es:" + alumno.Nacionalidad);
System.out.println("Mi estatura es:" + alumno.estatura);
System.out.println("Mi peso es:" + alumno.peso);

      
       
}
      
        




    
}
