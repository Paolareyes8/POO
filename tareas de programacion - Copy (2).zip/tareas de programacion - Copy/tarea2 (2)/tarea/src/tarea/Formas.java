
package tarea;


public class Formas {
    private String color;



    public void Dibujar() {
        System.out.println("vamos a dibujar: ");
        
    }
    
    
    
}
