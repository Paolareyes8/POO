
package tarea;


public class circulo extends Formas{
    private int area;
    
    public circulo(int area){
        this.area = area;
    }
    
    @Override
    public void Dibujar(){
        System.out.println("Usted a Dibujado un circulo");
    }
    
    public void mostrardatos(){
        System.out.println("El area es: "+area);
    }

 }
