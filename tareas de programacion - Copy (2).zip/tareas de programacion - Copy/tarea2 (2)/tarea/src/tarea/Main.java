
package tarea;

public class Main{
    public static void main(String [] args){
        circulo c1 = new circulo(22);
        lineas l1 = new lineas(65);
        triangulo t1 = new triangulo (36);
        cuadrado cu1 = new cuadrado(55);
        
        
        c1.Dibujar();
        c1.mostrardatos();
        l1.Dibujar();
        l1.mostrardatos();
        t1.Dibujar();
        t1.mostrardatos();
        cu1.Dibujar();
        cu1.mostrardatos();
    }
}
