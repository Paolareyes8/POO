
package tarea;


public class lineas extends Formas{
    private int largo;
    
    public lineas(int largo){
        this.largo = largo;
    }
    
    @Override
    public void Dibujar(){
        System.out.println("Usted esta dibujando una linea: "+largo);
    }
     public void mostrardatos(){
        System.out.println("El largo es: "+largo);
    }
}
