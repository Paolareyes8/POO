
package tarea;


public class cuadrado extends Formas{
   
    private int area;
    
    
    public cuadrado(int area){
        this.area = area;
    }
    
    @Override
    public void Dibujar(){
        System.out.println("Usted a dibujado un Cuadrado");
    }

 public void mostrardatos(){
        System.out.println("El area del cuadrado es: "+area);
    }

}

