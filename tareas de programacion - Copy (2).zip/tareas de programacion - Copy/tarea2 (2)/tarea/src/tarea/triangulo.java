
package tarea;


public class triangulo extends Formas{
    
private int angulo;
  
public triangulo(int angulo){
    this.angulo = angulo;
    
}

@Override
public void Dibujar(){
    System.out.println("Usted a dibujado un triangulo");
}


 public void mostrardatos(){
        System.out.println("El angulo es: "+angulo);
    }    
    
   
}
